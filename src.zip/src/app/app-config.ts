export class Config {
  public static config = {
    theme: 'vertical', // vertical, collapsed, horizontal
    themeType: 'default' // default, dark, light
  };
}
